package com.dt.spark.cores

import org.apache.spark.sql.SparkSession

/**
  * Created by hp on 2016/8/29.
  */
object Wordcount {
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder
      .appName("Spark Pi").master("local[4]")
      .getOrCreate()

//    val totalLines = spark.sparkContext.textFile("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\README.md").count()
//    println("totalLines = " + totalLines)

    spark.sparkContext.textFile("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\README.txt").
      flatMap(line => line.split(" ")
    ).map(word => (word,1)).reduceByKey(_+_).foreach(pair => println(pair._1 + " : " + pair._2))
//    spark.sparkContext.textFile("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\README.md").flatMap(line => line.split(" ")
//    ).map(word => (word,1)).reduceByKey(_+_).map(pair => (pair._2, pair._1)).sortByKey(false).collect()
//      .map(pair => (pair._2, pair._1)).foreach(pair => println(pair._1 + " : " + pair._2))

    while(true){}

    spark.stop()

  }
}
