package com.dt.spark.cores

import org.apache.spark.sql.SparkSession

object DatasetOps {
  case class Person(name:String, age: Long)
  case class Score(n:String, score: Long)
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder
      .appName("DatasetOps").master("local[4]")
      .config("spark.sql.warehouse.dir", "D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\spark-warehouse")
      .getOrCreate()

    import org.apache.spark.sql.functions._
    import spark.implicits._

    /**
      * Dataset中的tranformation和Action操作，Action类型的操作有：
      * show collect first reduce take count等
      * 这些操作都会产生结果，也就是说会执行逻辑计算的过程
      */

    val personsDF = spark.read.json("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\examples\\src\\main\\resources\\people.json")
    val personScoresDF = spark.read.json("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\examples\\src\\main\\resources\\peopleScores.json")

    val personsDS = personsDF.as[Person]
    val personScoresDS = personScoresDF.as[Score]

    personsDS.groupBy($"name", $"age").agg(concat($"name",$"age")).show

//    personsDS.groupBy($"name").agg(sum($"age"),avg($"age"),max($"age"),min($"age"),count($"age")
//        ,countDistinct($"age"), mean($"age"), current_date()).show

//    personsDS.groupBy($"name")
//          .agg(collect_list($"name"), collect_set($"name"))
//              .collect().foreach(println)


//      personsDS.sample(false, 0.5).show()
//    personsDS.randomSplit(Array(10,20)).foreach(dataset => dataset.show())

//    personsDS.joinWith(personScoresDS, $"name" === $"n").show

//    personsDS.sort($"age".desc).show

//    personsDS.map{person =>
//      (person.name,  person.age +100L)
//    }.show()
//    personsDS.mapPartitions{persons =>
//      val result = ArrayBuffer[(String, Long)]()
//      while(persons.hasNext){
//        val person = persons.next()
//        result += ((person.name, person.age + 1000))
//      }
//      result.iterator
//
//    }.show
//
//    personsDS.dropDuplicates("name").show()
//    personsDS.distinct().show()

//    println(personsDS.rdd.partitions.size)
//
//    val repartitionedDS = personsDS.repartition(4)
//    println(repartitionedDS.rdd.partitions.size)
//
//    val coalesced = repartitionedDS.repartition(2)
//    println(coalesced.rdd.partitions.size)
//    repartitionedDS.show()



//    personsDF.filter("age > 20").join(personScoresDF, $"name" === $"n").
//      groupBy(personsDF("name")).agg(avg(personScoresDF("score")),avg(personsDF("age"))).show()

//        personsDF.show()
//    personsDF.collect().foreach(println)

//      println(personsDF.count())

//      println(personsDF.first())

//      personsDF.take(2).foreach(println)

//      personsDF.foreach(item => println(item))
//      println(personsDF.map(person => 1).reduce(_+_))
//        val personsDS = personsDF.as[Person]
//        personsDS.show()
//        personsDS.printSchema()

//        personsDF.createOrReplaceTempView("persons")
//
//        spark.sql("SELECT * FROM persons WHERE age >20").explain()

//    while(true){}



    spark.stop()

  }
}
