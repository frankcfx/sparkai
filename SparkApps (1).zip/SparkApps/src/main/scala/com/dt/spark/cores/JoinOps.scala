package com.dt.spark.cores

import org.apache.spark.sql.SparkSession

/**
  * Created by hp on 2016/8/29.
  */
object JoinOps {
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder
      .appName("Spark Pi").master("local[4]")
      .getOrCreate()

   spark.sparkContext.parallelize(Array((1,"spark"),(2,"Hadoop"),(3,"scala"))).
     join(spark.sparkContext.parallelize(Array((1,100),(2,90),(3,90)))).foreach(item => {
     println(item)
   }

   )

    while(true){}

    spark.stop()

  }
}
