package com.dt.spark.cores

import org.apache.spark.sql.SparkSession

/**
  * Created by hp on 2016/8/29.
  */
object SparkTransformationsOps {
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder
      .appName("Spark Pi").master("local[4]")
      .getOrCreate()

    val totalLines = spark.sparkContext.textFile("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\README.md").count()
    println("totalLines = " + totalLines)

    val cp = spark.sparkContext.textFile("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\README.md").flatMap(line => line.split(" ")
    ).map(word => (word,1))
//      cp.reduceByKey((v1:Int, v2:Int) => v1 + v2).map(pair => (pair._2, pair._1)).sortByKey(false)
//          .cache.map(pair => (pair._2, pair._1))
//      cp.checkpoint()
//
//      cp.collect().foreach(pair => println(pair._1 + " : " + pair._2))

    cp.groupByKey().collect().foreach(pair => println(pair._1 + " : " + pair._2))

//    spark.sparkContext.textFile("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\README.md").flatMap(line => line.split(" ")
//    ).map(word => (word,1)).reduceByKey(_+_).collect().foreach(pair => println(pair._1 + " : " + pair._2))

    while(true){}

    spark.stop()

  }
}
