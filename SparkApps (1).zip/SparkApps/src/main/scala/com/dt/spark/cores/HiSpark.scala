package com.dt.spark.cores

import org.apache.spark.SparkConf
import org.apache.spark.sql.{Row, SparkSession}


object HiSpark {
  
  case class Person(name: String, age: Long)
  
  def main(args: Array[String]) {
    val conf = new SparkConf().setMaster("local[3]").setAppName("HiSpark")

    val spark = SparkSession
        .builder()
        .config(conf)
        .config("spark.sql.warehouse.dir", "D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\spark-warehouse")
        .enableHiveSupport()
        .getOrCreate()
    
    import spark.implicits._
    import org.apache.spark.sql.functions._
    
    val persons = spark.read.json("D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\examples\\src\\main\\resources\\people.json")

    val personsDS = persons.as[Person]
    personsDS.show()
    personsDS.printSchema()
    
    val personsDF = personsDS.toDF()

    spark.sql("CREATE TABLE IF NOT EXISTS src(key INT, value STRING)")
    spark.sql("LOAD DATA LOCAL INPATH 'D:\\Big_Data_Software\\spark-2.0.0-bin-hadoop2.6\\examples\\src\\main\\resources\\kv1.txt' INTO TABLE src")
    spark.sql("SELECT * FROM src").show()
    spark.sql("SELECT COUNT(*) FROM src").show()
//    val sqlDF = spark.sql("SELECT key,value FROM src WHERE key < 10 ORDER BY key")
//    sqlDF.map(row: Row => s"KEY: $key, VALUE: $value")
  }
  
}