#!/usr/bin/python
# encoding: utf-8


"""
author: 大圣
contact: 626494970@qq.com 
@file: anava_ana.py

 
如果出现 raise ValueError("For numerical factors, num_columns " ValueError: For numerical factors, num_columns must be an int


需要更新patsy包到0.4.1 ,
pip install --upgrade patsy

"""

import  pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

data=pd.read_csv('bike_day.csv',index_col=0)
week_mean =data.groupby('weekday').mean().cnt
print week_mean

holiday_mean= data.groupby('holiday').mean().cnt
print holiday_mean
# week_mean.plot()
# plt.show()
# print data.weekday.dtypes
# formula = 'cnt~weekday'
# anova_results = anova_lm(ols(formula,data).fit())
# print anova_results

# formula = 'cnt~holiday'
# anova_results = anova_lm(ols(formula,data).fit())
# print anova_results

formula = 'cnt~weekday+holiday+weekday:holiday'
anova_results = anova_lm(ols(formula,data).fit())
print anova_results