#!/usr/bin/python
# encoding: utf-8


"""
author: 大圣
contact: 626494970@qq.com 
@file: matrix_demo.py

 


"""
import numpy as np

a = np.mat('0.31 0.68 0.01')
b = np.mat('0.01 0.01 0.98')

tm = np.mat('0.65 0.28 0.07 ; 0.15 0.67 0.18 ; 0.12 0.36 0.52')
# print a,b,tm
#
# print a* tm ** 11
#
# print b* tm ** 11

# print a.T
print tm.I * tm