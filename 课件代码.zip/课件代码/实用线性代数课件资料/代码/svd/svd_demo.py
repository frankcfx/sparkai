#!/usr/bin/python
# encoding: utf-8


"""
author: 大圣
contact: 626494970@qq.com 
@file: svd_demo.py

 


"""
import numpy as np
a = np.arange(24).reshape(4, 6)
print "a:", a
u, sigma, v = np.linalg.svd(a)
print "u:", u       #  分解出的u矩阵
print "sigma:", sigma       #   分解出的奇异值向量
print "v:", v       #  分解出的v矩阵


def restore(sigma,u,v,k):
    u2 = u[:,:k]
    v2 = v[:k,:]
    s2=np.eye(k)
    for i in range(k):
        s2[i,i] = sigma[i]
    return np.dot(np.dot(u2,s2),v2)

print restore(sigma, u, v, 2)
