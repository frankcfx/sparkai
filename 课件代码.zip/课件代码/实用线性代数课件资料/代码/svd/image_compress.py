#!/usr/bin/python
# encoding: utf-8


"""
author: 大圣
contact: 626494970@qq.com 
@file: image_compress.py

 


"""

import numpy as np
from matplotlib import pyplot as plt

def restore(sigma,u,v,k):
    u2 = u[:,:k]
    v2 = v[:k,:]
    s2=np.eye(k)
    for i in range(k):
        s2[i,i] = sigma[i]
    return np.dot(np.dot(u2,s2),v2)

def svdimage(filename,percent):
    original=plt.imread(filename)
    R0=np.array(original[:,:,0])
    G0=np.array(original[:,:,1])
    B0=np.array(original[:,:,2])
    u0,sigma0,v0=np.linalg.svd(R0)
    u1,sigma1,v1=np.linalg.svd(G0)
    u2,sigma2,v2=np.linalg.svd(B0)


    # k= int(percent*len(sigma0))+1
    k = percent

    R1 = restore(sigma0,u0,v0,k)
    G1 = restore(sigma1,u1,v1,k)
    B1 = restore(sigma2,u2,v2,k)

    final=np.stack((R1,G1,B1),2)
    final[final>255]=255
    final[final<0]=0
    final=np.rint(final).astype('uint8')
    return k,final

if __name__=='__main__':
    filename='flower.jpg'
    for p in np.arange(1,100,10):
        k,after=svdimage(filename,p)
        plt.imsave(str(p)+'_{0}.jpg'.format(k),after)